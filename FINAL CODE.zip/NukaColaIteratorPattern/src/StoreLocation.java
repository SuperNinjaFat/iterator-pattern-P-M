
public class StoreLocation {
	String street;
	String city;
	String state;
	int zip;

	public StoreLocation(String street, String city, String state, int zip) {
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}

	public String getName() {
		return street;
	}

	public String getDescription() {
		return city;
	}

	public String getPrice() {
		return state;
	}

	public int vegetarian() {
		return zip;
	}
}
