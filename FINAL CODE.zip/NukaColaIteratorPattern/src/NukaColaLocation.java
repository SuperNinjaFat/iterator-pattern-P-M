
public class NukaColaLocation {
	static final int MAX_ITEMS = 6;
	int numberOfItems = 0;
	StoreLocation[] menuItems;

	public NukaColaLocation() {
		menuItems = new StoreLocation[MAX_ITEMS];

		addItem("3258 Nuka-World Lane", "San Diego", "California", 92130);
		addItem("375 Maple Street", "Burlington", "Vermont", 05401);
	}

	private void addItem(String street, String city, String state, int zip) {
		StoreLocation menuItem = new StoreLocation(street, city, state, zip);
		if (numberOfItems >= MAX_ITEMS) {
			System.err.println("Sorry, menu is full! Can't add item to menu");
		} else {
			menuItems[numberOfItems] = menuItem;
			numberOfItems = numberOfItems + 1;
		}
	}

	public Iterator createIterator() {
		return new NukaColaIterator(menuItems);
	}
}
