
public class NukaColaIterator implements Iterator {

	StoreLocation[] items;
	int position = 0;

	public NukaColaIterator(StoreLocation[] menuItems) {
		this.items = menuItems;
	}

	public Object next() {
		StoreLocation menuItem = items[position];
		position = position + 1;
		return menuItem;
	}

	public boolean hasNext() {
		if (position >= items.length || items[position] == null)
			return false;
		else
			return true;
	}
}
