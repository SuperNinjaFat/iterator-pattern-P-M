
public class IteratorTest {
	public static void main(String[] args) {
		SunsetSarsaparillaLocation sunsetMenu = new SunsetSarsaparillaLocation();
		NukaColaLocation nukaColaMenu = new NukaColaLocation();

		Display waitress = new Display(sunsetMenu, nukaColaMenu);

		waitress.printMenu();
	}
}
