
public class Display {
	SunsetSarsaparillaLocation sunsetMenu;
	NukaColaLocation nukaColaDiner;

	public Display(SunsetSarsaparillaLocation sunsetMenu, NukaColaLocation nukaColaDiner) {
		this.sunsetMenu = sunsetMenu;
		this.nukaColaDiner = nukaColaDiner;
	}

	public void printMenu() {
		Iterator sunsetSarsaparillaIterator = sunsetMenu.createIterator();
		Iterator nukaColaIterator = nukaColaDiner.createIterator();
		System.out.println("Menu\n----\nSunset Sarsaparilla Locations");
		printMenu(sunsetSarsaparillaIterator);
		System.out.println("\nNuka Cola Locations");
		printMenu(nukaColaIterator);
	}

	private void printMenu(Iterator iterator) {
		while (iterator.hasNext()) {
			StoreLocation menuItem = (StoreLocation) iterator.next();
			System.out.print(menuItem.getName() + ", ");
			System.out.print(menuItem.getPrice() + " -- ");
			System.out.println(menuItem.getDescription());
		}
	}
}
