import java.util.ArrayList;

public class SunsetSarsaparillaLocation {

	ArrayList<StoreLocation> menuItems;
	SunsetSarsaparillaIterator sunset;

	public SunsetSarsaparillaLocation() {
		menuItems = new ArrayList<StoreLocation>();

		addItem("111 Lower Ridge Road", "New England", "Boston", 99999);
		addItem("194 Saint Paul Street", "Burlington", "Vermont", 05401);
	}

	public void addItem(String street, String city, String state, int zip) {
		StoreLocation menuItem = new StoreLocation(street, city, state, zip);
		menuItems.add(menuItem);
	}

	public ArrayList<StoreLocation> getMenuItems() {
		return menuItems;
	}

	public Iterator createIterator() {
		return new SunsetSarsaparillaIterator(menuItems);
	}
}