import java.util.ArrayList;

public class PancakeHouseIterator implements Iterator {

	ArrayList<MenuItem> items;
	int nextIdx;
	
	public PancakeHouseIterator(ArrayList<MenuItem> menuItems) {
		this.items = menuItems;
		this.nextIdx = 0;
	}

	public Object next() {
		Object T = this.items.get(this.nextIdx);
		this.nextIdx = this.nextIdx + 1;
		return T;
	}

	public boolean hasNext() {
		return this.nextIdx < this.items.size();
	}
}
