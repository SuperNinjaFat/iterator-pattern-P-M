
public class Display {
	SunsetSarsaparillaMenu sunsetMenu;
	NukaColaDiner nukaColaDiner;

	public Display(SunsetSarsaparillaMenu sunsetMenu, NukaColaDiner nukaColaDiner) {
		this.sunsetMenu = sunsetMenu;
		this.nukaColaDiner = nukaColaDiner;
	}

	public void printMenu() {
		Iterator pancakeIterator = sunsetMenu.createIterator();
		Iterator nukaColaIterator = nukaColaDiner.createIterator();
		System.out.println("Menu\n----\nBREAKFAST");
		printMenu(pancakeIterator);
		System.out.println("\nLUNCH");
		printMenu(nukaColaIterator);
	}

	private void printMenu(Iterator iterator) {
		while (iterator.hasNext()) {
			MenuItem menuItem = (MenuItem) iterator.next();
			System.out.print(menuItem.getName() + ", ");
			System.out.print(menuItem.getPrice() + " -- ");
			System.out.println(menuItem.getDescription());
		}
	}
}
