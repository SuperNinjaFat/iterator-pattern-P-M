
public class IteratorTest {
	public static void main(String[] args) {
		SunsetSarsaparillaMenu sunsetMenu = new SunsetSarsaparillaMenu();
		NukaColaDiner nukaColaMenu = new NukaColaDiner();

		Display waitress = new Display(sunsetMenu, nukaColaMenu);

		waitress.printMenu();
	}
}
